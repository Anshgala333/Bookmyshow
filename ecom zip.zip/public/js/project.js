// console.log($);
// console.log(jQuery);
const API = "http://localhost:3000" 

$(document).ready(function() {
    $("#theatreform").submit(function(ev) {
        ev.preventDefault();
        $("#para").removeClass("alert alert-success ")
        if($("#txtbox").val() != ""){
        var formData =  $("#theatreform").serialize()
        // console.log(formData);
        $.ajax({
            type : "POST",
            data : formData,
            url  : API + "/theatre",
            success : function(res){
                console.log(res);
                $("#para").addClass("alert alert-success").text("record added")
                $("#txtbox").val("")
            },

            err : function(err){
                console.log(err);
            }
        })
    }
    else{
        $("#para").addClass("alert alert-danger").text("name requires")
        $("#txtbox").val('')
    }


    })

})
// $(window).load(function() {

// })